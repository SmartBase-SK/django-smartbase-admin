# django-smartbase-admin
SmartBase Admin application for Django.
